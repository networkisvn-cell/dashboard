import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Settings, 
  MessageSquare, 
  Trophy, 
  Ticket, 
  ShieldAlert, 
  Coins, 
  ScrollText,
  Home,
  LogOut,
  ChevronLeft
} from "lucide-react";
import { useGetGuild } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";

interface DashboardLayoutProps {
  children: ReactNode;
  guildId?: string;
}

export function DashboardLayout({ children, guildId }: DashboardLayoutProps) {
  const [location] = useLocation();

  const { data: guild, isLoading } = useGetGuild(guildId || "", {
    query: {
      enabled: !!guildId,
    }
  });

  const links = [
    { href: `/dashboard/${guildId}`, label: "Overview", icon: LayoutDashboard },
    { href: `/dashboard/${guildId}/moderation`, label: "Moderation", icon: ShieldAlert },
    { href: `/dashboard/${guildId}/welcome`, label: "Welcome", icon: MessageSquare },
    { href: `/dashboard/${guildId}/levels`, label: "Leveling", icon: Trophy },
    { href: `/dashboard/${guildId}/leaderboard`, label: "Leaderboard", icon: Trophy },
    { href: `/dashboard/${guildId}/tickets`, label: "Tickets", icon: Ticket },
    { href: `/dashboard/${guildId}/security`, label: "Security", icon: ShieldAlert },
    { href: `/dashboard/${guildId}/economy`, label: "Economy", icon: Coins },
    { href: `/dashboard/${guildId}/logs`, label: "Audit Logs", icon: ScrollText },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-sidebar flex flex-col hidden md:flex shrink-0">
        <div className="p-6 border-b border-border flex flex-col gap-4">
          <Link href="/" className="flex items-center gap-2 text-primary font-bold text-xl tracking-wider uppercase hover:opacity-80 transition-opacity">
            <ShieldAlert className="w-6 h-6" />
            NAKKHOTRO
          </Link>

          {guildId ? (
            <div className="flex items-center gap-3 mt-4">
              {isLoading ? (
                <Skeleton className="w-10 h-10 rounded-full bg-border" />
              ) : guild?.icon ? (
                <img src={guild.icon} alt={guild.name} className="w-10 h-10 rounded-full border border-border" />
              ) : (
                <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center font-bold">
                  {guild?.name?.[0] || "?"}
                </div>
              )}
              <div className="flex flex-col overflow-hidden">
                {isLoading ? (
                  <>
                    <Skeleton className="w-24 h-4 mb-1 bg-border" />
                    <Skeleton className="w-16 h-3 bg-border" />
                  </>
                ) : (
                  <>
                    <span className="font-semibold text-sm truncate">{guild?.name}</span>
                    <span className="text-xs text-muted-foreground">{guild?.memberCount} Members</span>
                  </>
                )}
              </div>
            </div>
          ) : null}
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          <Link href="/dashboard">
            <Button variant="ghost" className="w-full justify-start text-muted-foreground hover:text-foreground mb-4">
              <ChevronLeft className="w-4 h-4 mr-2" />
              Change Server
            </Button>
          </Link>
          
          {guildId && links.map((link) => {
            const isActive = location === link.href;
            const Icon = link.icon;
            
            return (
              <Link key={link.href} href={link.href}>
                <Button 
                  variant={isActive ? "secondary" : "ghost"} 
                  className={`w-full justify-start ${isActive ? "bg-primary/10 text-primary border border-primary/20" : "text-muted-foreground"}`}
                >
                  <Icon className="w-4 h-4 mr-3" />
                  {link.label}
                </Button>
              </Link>
            );
          })}
        </nav>
        
        <div className="p-4 border-t border-border">
          <Button variant="outline" className="w-full justify-start text-muted-foreground border-border hover:bg-destructive/10 hover:text-destructive hover:border-destructive/20">
            <LogOut className="w-4 h-4 mr-3" />
            Disconnect
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-h-screen overflow-hidden">
        <div className="flex-1 overflow-y-auto p-6 md:p-10">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}