import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { LandingPage } from "./pages/landing";
import { GuildSelector } from "./pages/dashboard/index";
import { GuildOverview } from "./pages/dashboard/guild";
import { ModerationPage } from "./pages/dashboard/moderation";
import { WelcomePage } from "./pages/dashboard/welcome";
import { LevelsPage } from "./pages/dashboard/levels";
import { LeaderboardPage } from "./pages/dashboard/leaderboard";
import { TicketsPage } from "./pages/dashboard/tickets";
import { SecurityPage } from "./pages/dashboard/security";
import { EconomyPage } from "./pages/dashboard/economy";
import { LogsPage } from "./pages/dashboard/logs";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/dashboard" component={GuildSelector} />
      <Route path="/dashboard/:guildId" component={GuildOverview} />
      <Route path="/dashboard/:guildId/moderation" component={ModerationPage} />
      <Route path="/dashboard/:guildId/welcome" component={WelcomePage} />
      <Route path="/dashboard/:guildId/levels" component={LevelsPage} />
      <Route path="/dashboard/:guildId/leaderboard" component={LeaderboardPage} />
      <Route path="/dashboard/:guildId/tickets" component={TicketsPage} />
      <Route path="/dashboard/:guildId/security" component={SecurityPage} />
      <Route path="/dashboard/:guildId/economy" component={EconomyPage} />
      <Route path="/dashboard/:guildId/logs" component={LogsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
