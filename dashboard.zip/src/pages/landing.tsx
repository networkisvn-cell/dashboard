import { useLocation } from "wouter";
import { ShieldAlert, Activity, Users, Zap, TerminalSquare, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useGetStatsOverview } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

export function LandingPage() {
  const [, setLocation] = useLocation();
  const { data: stats, isLoading } = useGetStatsOverview();

  const handleLogin = () => {
    // Simulate OAuth
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen bg-[#050505] text-foreground flex flex-col relative overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] rounded-full bg-primary/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full bg-primary/5 blur-[120px] pointer-events-none" />

      {/* Navigation */}
      <header className="container mx-auto px-6 h-20 flex items-center justify-between border-b border-white/5 relative z-10">
        <div className="flex items-center gap-2 text-primary font-bold text-2xl tracking-widest uppercase">
          <ShieldAlert className="w-8 h-8" />
          NAKKHOTRO
        </div>
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
          <a href="#" className="hover:text-primary transition-colors">Features</a>
          <a href="#" className="hover:text-primary transition-colors">Commands</a>
          <a href="#" className="hover:text-primary transition-colors">Premium</a>
          <a href="#" className="hover:text-primary transition-colors">Support</a>
        </nav>
        <div>
          <Button onClick={handleLogin} className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold px-6 shadow-[0_0_15px_rgba(245,197,66,0.3)]">
            Login
          </Button>
        </div>
      </header>

      {/* Hero */}
      <main className="flex-1 flex flex-col items-center justify-center container mx-auto px-6 relative z-10 text-center py-20">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto flex flex-col items-center"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary mb-8 text-sm font-medium tracking-wide">
            <Zap className="w-4 h-4" />
            V2.0 is now live
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-8 leading-tight">
            Mission Control for <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-yellow-600">Discord Communities</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-12 max-w-2xl leading-relaxed">
            Military-grade precision meets premium aesthetics. Powerful moderation, advanced leveling, and deep analytics designed for people who take their servers seriously.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <Button onClick={handleLogin} size="lg" className="h-14 px-8 text-lg bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_30px_rgba(245,197,66,0.4)]">
              Add to Discord
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button onClick={handleLogin} variant="outline" size="lg" className="h-14 px-8 text-lg border-white/10 hover:bg-white/5 hover:text-white">
              Open Dashboard
            </Button>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 mt-24 w-full max-w-5xl"
        >
          <div className="flex flex-col items-center justify-center p-6 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-sm">
            <Activity className="w-6 h-6 text-primary mb-4 opacity-70" />
            {isLoading ? <Skeleton className="h-10 w-24 mb-2 bg-white/10" /> : <div className="text-4xl font-bold mb-1">{stats?.guilds?.toLocaleString() || "0"}</div>}
            <div className="text-sm text-muted-foreground uppercase tracking-widest font-medium">Servers</div>
          </div>
          <div className="flex flex-col items-center justify-center p-6 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-sm">
            <Users className="w-6 h-6 text-primary mb-4 opacity-70" />
            {isLoading ? <Skeleton className="h-10 w-24 mb-2 bg-white/10" /> : <div className="text-4xl font-bold mb-1">{stats?.users?.toLocaleString() || "0"}</div>}
            <div className="text-sm text-muted-foreground uppercase tracking-widest font-medium">Users</div>
          </div>
          <div className="flex flex-col items-center justify-center p-6 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-sm">
            <TerminalSquare className="w-6 h-6 text-primary mb-4 opacity-70" />
            {isLoading ? <Skeleton className="h-10 w-24 mb-2 bg-white/10" /> : <div className="text-4xl font-bold mb-1">{stats?.commands?.toLocaleString() || "0"}</div>}
            <div className="text-sm text-muted-foreground uppercase tracking-widest font-medium">Commands</div>
          </div>
          <div className="flex flex-col items-center justify-center p-6 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-sm">
            <Zap className="w-6 h-6 text-primary mb-4 opacity-70" />
            {isLoading ? <Skeleton className="h-10 w-24 mb-2 bg-white/10" /> : <div className="text-4xl font-bold mb-1">{stats?.ping || "0"}ms</div>}
            <div className="text-sm text-muted-foreground uppercase tracking-widest font-medium">Latency</div>
          </div>
        </motion.div>
      </main>
    </div>
  );
}