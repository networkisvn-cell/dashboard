import { useParams } from "wouter";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import {
  useGetModerationSettings,
  useUpdateModerationSettings,
} from "@workspace/api-client-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { Shield, Save } from "lucide-react";

export function ModerationPage() {
  const { guildId } = useParams<{ guildId: string }>();
  const { toast } = useToast();
  const { data, isLoading } = useGetModerationSettings(guildId!, {
    query: { enabled: !!guildId },
  });
  const { mutate, isPending } = useUpdateModerationSettings();

  const [form, setForm] = useState({
    autoMod: false,
    antiSpam: false,
    antiLinks: false,
    antiGhostPing: false,
    antiRaid: false,
    warnThreshold: 3,
    modLogChannelId: "",
  });

  useEffect(() => {
    if (data) {
      setForm({
        autoMod: data.autoMod ?? false,
        antiSpam: data.antiSpam ?? false,
        antiLinks: data.antiLinks ?? false,
        antiGhostPing: data.antiGhostPing ?? false,
        antiRaid: data.antiRaid ?? false,
        warnThreshold: data.warnThreshold ?? 3,
        modLogChannelId: data.modLogChannelId ?? "",
      });
    }
  }, [data]);

  const handleSave = () => {
    mutate(
      { guildId: guildId!, data: form },
      {
        onSuccess: () =>
          toast({ title: "Saved", description: "Moderation settings updated." }),
        onError: () =>
          toast({ title: "Error", description: "Failed to save settings.", variant: "destructive" }),
      },
    );
  };

  const toggle = (key: keyof typeof form) =>
    setForm((f) => ({ ...f, [key]: !f[key as keyof typeof form] }));

  return (
    <DashboardLayout guildId={guildId}>
      <div className="space-y-8 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Shield className="w-8 h-8 text-primary" />
            Moderation
          </h1>
          <p className="text-muted-foreground mt-1">Configure automated moderation and punishment settings</p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-16 bg-border rounded-xl" />
            ))}
          </div>
        ) : (
          <>
            <div className="bg-card border border-border rounded-xl divide-y divide-border">
              {[
                { key: "autoMod", label: "AutoMod", desc: "Enable automatic content moderation" },
                { key: "antiSpam", label: "Anti-Spam", desc: "Timeout users who send messages too quickly" },
                { key: "antiLinks", label: "Anti-Links", desc: "Delete unauthorized links automatically" },
                { key: "antiGhostPing", label: "Anti-Ghost Ping", desc: "Alert when users ghost ping others" },
                { key: "antiRaid", label: "Anti-Raid", desc: "Detect and block mass-join raids" },
              ].map(({ key, label, desc }) => (
                <div key={key} className="flex items-center justify-between p-5">
                  <div>
                    <Label className="text-base font-medium">{label}</Label>
                    <p className="text-sm text-muted-foreground">{desc}</p>
                  </div>
                  <Switch
                    checked={form[key as keyof typeof form] as boolean}
                    onCheckedChange={() => toggle(key as keyof typeof form)}
                  />
                </div>
              ))}
            </div>

            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <h3 className="font-semibold">Punishment Settings</h3>
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label>Warn Threshold (auto-action)</Label>
                  <Input
                    type="number"
                    min={1}
                    max={10}
                    value={form.warnThreshold}
                    onChange={(e) => setForm((f) => ({ ...f, warnThreshold: parseInt(e.target.value) || 3 }))}
                    className="bg-background border-border max-w-xs"
                  />
                  <p className="text-xs text-muted-foreground">
                    Users reaching this many warnings will be automatically actioned
                  </p>
                </div>
                <div className="space-y-2">
                  <Label>Mod Log Channel ID</Label>
                  <Input
                    value={form.modLogChannelId}
                    onChange={(e) => setForm((f) => ({ ...f, modLogChannelId: e.target.value }))}
                    placeholder="Channel ID..."
                    className="bg-background border-border max-w-xs"
                  />
                </div>
              </div>
            </div>

            <Button
              onClick={handleSave}
              disabled={isPending}
              className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Save className="w-4 h-4" />
              {isPending ? "Saving..." : "Save Changes"}
            </Button>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
