import { useParams } from "wouter";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import {
  useGetSecuritySettings,
  useUpdateSecuritySettings,
} from "@workspace/api-client-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { ShieldAlert, Save, AlertTriangle } from "lucide-react";

export function SecurityPage() {
  const { guildId } = useParams<{ guildId: string }>();
  const { toast } = useToast();
  const { data, isLoading } = useGetSecuritySettings(guildId!, {
    query: { enabled: !!guildId },
  });
  const { mutate, isPending } = useUpdateSecuritySettings();

  const [form, setForm] = useState({
    antiNuke: false,
    antiBotAdd: false,
    antiWebhook: false,
    antiRoleDelete: false,
    antiChannelDelete: false,
    antiPermissionAbuse: false,
    whitelistEnabled: false,
    auditLogChannelId: "",
  });

  useEffect(() => {
    if (data) {
      setForm({
        antiNuke: data.antiNuke ?? false,
        antiBotAdd: data.antiBotAdd ?? false,
        antiWebhook: data.antiWebhook ?? false,
        antiRoleDelete: data.antiRoleDelete ?? false,
        antiChannelDelete: data.antiChannelDelete ?? false,
        antiPermissionAbuse: data.antiPermissionAbuse ?? false,
        whitelistEnabled: data.whitelistEnabled ?? false,
        auditLogChannelId: data.auditLogChannelId ?? "",
      });
    }
  }, [data]);

  const handleSave = () => {
    mutate(
      { guildId: guildId!, data: form },
      {
        onSuccess: () => toast({ title: "Saved", description: "Security settings updated." }),
        onError: () => toast({ title: "Error", description: "Failed to save.", variant: "destructive" }),
      },
    );
  };

  const toggle = (key: keyof typeof form) =>
    setForm((f) => ({ ...f, [key]: !f[key as keyof typeof form] }));

  const anyEnabled = Object.entries(form)
    .filter(([k]) => k !== "auditLogChannelId")
    .some(([, v]) => v === true);

  return (
    <DashboardLayout guildId={guildId}>
      <div className="space-y-8 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <ShieldAlert className="w-8 h-8 text-primary" />
            Anti-Nuke Security
          </h1>
          <p className="text-muted-foreground mt-1">Protect your server against destructive attacks</p>
        </div>

        {anyEnabled && (
          <div className="flex items-start gap-3 p-4 rounded-xl bg-primary/10 border border-primary/20">
            <AlertTriangle className="w-5 h-5 text-primary shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-primary">Security Active</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                One or more anti-nuke features are enabled. Make sure trusted admins are whitelisted.
              </p>
            </div>
          </div>
        )}

        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5, 6].map((i) => <Skeleton key={i} className="h-16 bg-border rounded-xl" />)}
          </div>
        ) : (
          <>
            <div className="bg-card border border-border rounded-xl divide-y divide-border">
              {[
                { key: "antiNuke", label: "Anti-Nuke", desc: "Detect and punish mass destructive actions (bans, kicks, deletes)" },
                { key: "antiBotAdd", label: "Anti-Bot Add", desc: "Prevent unauthorized bots from being added" },
                { key: "antiWebhook", label: "Anti-Webhook", desc: "Block unauthorized webhook creation" },
                { key: "antiRoleDelete", label: "Anti-Role Delete", desc: "Protect against mass role deletion" },
                { key: "antiChannelDelete", label: "Anti-Channel Delete", desc: "Protect against mass channel deletion" },
                { key: "antiPermissionAbuse", label: "Anti-Perm Abuse", desc: "Detect and revert dangerous role assignments" },
                { key: "whitelistEnabled", label: "Whitelist Mode", desc: "Only whitelisted users can perform admin actions" },
              ].map(({ key, label, desc }) => (
                <div key={key} className="flex items-center justify-between p-5">
                  <div>
                    <Label className="text-base font-medium">{label}</Label>
                    <p className="text-sm text-muted-foreground">{desc}</p>
                  </div>
                  <Switch
                    checked={form[key as keyof typeof form] as boolean}
                    onCheckedChange={() => toggle(key as keyof typeof form)}
                  />
                </div>
              ))}
            </div>

            <div className="bg-card border border-border rounded-xl p-6 space-y-4">
              <h3 className="font-semibold">Logging</h3>
              <div className="space-y-2">
                <Label>Audit Log Channel ID</Label>
                <Input
                  value={form.auditLogChannelId}
                  onChange={(e) => setForm((f) => ({ ...f, auditLogChannelId: e.target.value }))}
                  placeholder="Security alerts will be sent here..."
                  className="bg-background border-border"
                />
              </div>
            </div>

            <Button
              onClick={handleSave}
              disabled={isPending}
              className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Save className="w-4 h-4" />
              {isPending ? "Saving..." : "Save Changes"}
            </Button>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
