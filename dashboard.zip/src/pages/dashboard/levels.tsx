import { useParams } from "wouter";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import {
  useGetLevelSettings,
  useUpdateLevelSettings,
} from "@workspace/api-client-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { Trophy, Save } from "lucide-react";

export function LevelsPage() {
  const { guildId } = useParams<{ guildId: string }>();
  const { toast } = useToast();
  const { data, isLoading } = useGetLevelSettings(guildId!, {
    query: { enabled: !!guildId },
  });
  const { mutate, isPending } = useUpdateLevelSettings();

  const [form, setForm] = useState({
    enabled: true,
    xpPerMessage: 15,
    xpCooldown: 60,
    levelUpChannelId: "",
    levelUpMessage: "Congratulations {user}! You reached level {level}!",
    vcXpEnabled: false,
    vcXpPerMinute: 5,
  });

  useEffect(() => {
    if (data) {
      setForm({
        enabled: data.enabled ?? true,
        xpPerMessage: data.xpPerMessage ?? 15,
        xpCooldown: data.xpCooldown ?? 60,
        levelUpChannelId: data.levelUpChannelId ?? "",
        levelUpMessage: data.levelUpMessage ?? "Congratulations {user}! You reached level {level}!",
        vcXpEnabled: data.vcXpEnabled ?? false,
        vcXpPerMinute: data.vcXpPerMinute ?? 5,
      });
    }
  }, [data]);

  const handleSave = () => {
    mutate(
      { guildId: guildId!, data: form },
      {
        onSuccess: () => toast({ title: "Saved", description: "Leveling settings updated." }),
        onError: () => toast({ title: "Error", description: "Failed to save.", variant: "destructive" }),
      },
    );
  };

  return (
    <DashboardLayout guildId={guildId}>
      <div className="space-y-8 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Trophy className="w-8 h-8 text-primary" />
            Leveling System
          </h1>
          <p className="text-muted-foreground mt-1">Configure XP gain and level-up rewards</p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 bg-border rounded-xl" />)}
          </div>
        ) : (
          <>
            <div className="bg-card border border-border rounded-xl p-6 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">Enable Leveling</Label>
                  <p className="text-sm text-muted-foreground">Users earn XP for sending messages</p>
                </div>
                <Switch
                  checked={form.enabled}
                  onCheckedChange={(v) => setForm((f) => ({ ...f, enabled: v }))}
                />
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>XP Per Message</Label>
                  <span className="text-primary font-mono text-sm">{form.xpPerMessage} XP</span>
                </div>
                <Slider
                  value={[form.xpPerMessage]}
                  min={1}
                  max={100}
                  step={1}
                  onValueChange={([v]) => setForm((f) => ({ ...f, xpPerMessage: v }))}
                  disabled={!form.enabled}
                  className="[&_[role=slider]]:bg-primary"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>1</span><span>50</span><span>100</span>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>XP Cooldown</Label>
                  <span className="text-primary font-mono text-sm">{form.xpCooldown}s</span>
                </div>
                <Slider
                  value={[form.xpCooldown]}
                  min={5}
                  max={300}
                  step={5}
                  onValueChange={([v]) => setForm((f) => ({ ...f, xpCooldown: v }))}
                  disabled={!form.enabled}
                  className="[&_[role=slider]]:bg-primary"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>5s</span><span>150s</span><span>300s</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Level-Up Channel ID</Label>
                <Input
                  value={form.levelUpChannelId}
                  onChange={(e) => setForm((f) => ({ ...f, levelUpChannelId: e.target.value }))}
                  placeholder="Leave empty to use the same channel"
                  className="bg-background border-border"
                />
              </div>

              <div className="space-y-2">
                <Label>Level-Up Message</Label>
                <Input
                  value={form.levelUpMessage}
                  onChange={(e) => setForm((f) => ({ ...f, levelUpMessage: e.target.value }))}
                  className="bg-background border-border"
                />
                <p className="text-xs text-muted-foreground">
                  Variables: <code className="text-primary">{"{user}"}</code>{" "}
                  <code className="text-primary">{"{level}"}</code>
                </p>
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">Voice Channel XP</Label>
                  <p className="text-sm text-muted-foreground">Users earn XP while in voice channels</p>
                </div>
                <Switch
                  checked={form.vcXpEnabled}
                  onCheckedChange={(v) => setForm((f) => ({ ...f, vcXpEnabled: v }))}
                />
              </div>

              {form.vcXpEnabled && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>XP Per Minute (VC)</Label>
                    <span className="text-primary font-mono text-sm">{form.vcXpPerMinute} XP/min</span>
                  </div>
                  <Slider
                    value={[form.vcXpPerMinute]}
                    min={1}
                    max={20}
                    step={1}
                    onValueChange={([v]) => setForm((f) => ({ ...f, vcXpPerMinute: v }))}
                    className="[&_[role=slider]]:bg-primary"
                  />
                </div>
              )}
            </div>

            <Button
              onClick={handleSave}
              disabled={isPending}
              className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Save className="w-4 h-4" />
              {isPending ? "Saving..." : "Save Changes"}
            </Button>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
