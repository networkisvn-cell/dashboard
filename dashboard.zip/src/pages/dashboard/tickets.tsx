import { useParams } from "wouter";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import {
  useGetTicketSettings,
  useUpdateTicketSettings,
} from "@workspace/api-client-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { Ticket, Save } from "lucide-react";

export function TicketsPage() {
  const { guildId } = useParams<{ guildId: string }>();
  const { toast } = useToast();
  const { data, isLoading } = useGetTicketSettings(guildId!, {
    query: { enabled: !!guildId },
  });
  const { mutate, isPending } = useUpdateTicketSettings();

  const [form, setForm] = useState({
    enabled: false,
    categoryId: "",
    supportRoleId: "",
    maxTickets: 3,
    ticketPrefix: "ticket",
    welcomeMessage: "Thank you for opening a ticket. Support will be with you shortly.",
  });

  useEffect(() => {
    if (data) {
      setForm({
        enabled: data.enabled ?? false,
        categoryId: data.categoryId ?? "",
        supportRoleId: data.supportRoleId ?? "",
        maxTickets: data.maxTickets ?? 3,
        ticketPrefix: data.ticketPrefix ?? "ticket",
        welcomeMessage: data.welcomeMessage ?? "",
      });
    }
  }, [data]);

  const handleSave = () => {
    mutate(
      { guildId: guildId!, data: form },
      {
        onSuccess: () => toast({ title: "Saved", description: "Ticket settings updated." }),
        onError: () => toast({ title: "Error", description: "Failed to save.", variant: "destructive" }),
      },
    );
  };

  return (
    <DashboardLayout guildId={guildId}>
      <div className="space-y-8 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Ticket className="w-8 h-8 text-primary" />
            Ticket System
          </h1>
          <p className="text-muted-foreground mt-1">Manage support ticket configuration</p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 bg-border rounded-xl" />)}
          </div>
        ) : (
          <>
            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">Enable Tickets</Label>
                  <p className="text-sm text-muted-foreground">Allow members to open support tickets</p>
                </div>
                <Switch
                  checked={form.enabled}
                  onCheckedChange={(v) => setForm((f) => ({ ...f, enabled: v }))}
                />
              </div>

              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label>Category ID</Label>
                  <Input
                    value={form.categoryId}
                    onChange={(e) => setForm((f) => ({ ...f, categoryId: e.target.value }))}
                    placeholder="Category where ticket channels will be created..."
                    className="bg-background border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Support Role ID</Label>
                  <Input
                    value={form.supportRoleId}
                    onChange={(e) => setForm((f) => ({ ...f, supportRoleId: e.target.value }))}
                    placeholder="Role with access to all tickets..."
                    className="bg-background border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Ticket Prefix</Label>
                  <Input
                    value={form.ticketPrefix}
                    onChange={(e) => setForm((f) => ({ ...f, ticketPrefix: e.target.value }))}
                    placeholder="ticket"
                    className="bg-background border-border max-w-xs"
                  />
                  <p className="text-xs text-muted-foreground">Channel name: {form.ticketPrefix}-XXXX</p>
                </div>
                <div className="space-y-2">
                  <Label>Max Open Tickets Per User</Label>
                  <Input
                    type="number"
                    min={1}
                    max={10}
                    value={form.maxTickets}
                    onChange={(e) => setForm((f) => ({ ...f, maxTickets: parseInt(e.target.value) || 3 }))}
                    className="bg-background border-border max-w-xs"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Welcome Message</Label>
                  <Input
                    value={form.welcomeMessage}
                    onChange={(e) => setForm((f) => ({ ...f, welcomeMessage: e.target.value }))}
                    className="bg-background border-border"
                  />
                </div>
              </div>
            </div>

            <Button
              onClick={handleSave}
              disabled={isPending}
              className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Save className="w-4 h-4" />
              {isPending ? "Saving..." : "Save Changes"}
            </Button>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
