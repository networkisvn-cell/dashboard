import { useParams, Link } from "wouter";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import {
  useGetGuild,
  useGetGuildAnalytics,
  useGetStatsOverview,
  useGetLeaderboard,
} from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Users,
  MessageSquare,
  TerminalSquare,
  Ticket,
  TrendingUp,
  Shield,
  Trophy,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

function StatCard({
  label,
  value,
  icon: Icon,
  isLoading,
  color = "text-primary",
}: {
  label: string;
  value: string | number | undefined;
  icon: React.ElementType;
  isLoading: boolean;
  color?: string;
}) {
  return (
    <div className="bg-card border border-border rounded-xl p-6 flex items-center gap-5">
      <div className={`w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center ${color}`}>
        <Icon className="w-6 h-6" />
      </div>
      <div>
        {isLoading ? (
          <Skeleton className="h-8 w-20 mb-1 bg-border" />
        ) : (
          <div className="text-2xl font-bold">{value?.toLocaleString() ?? "—"}</div>
        )}
        <div className="text-sm text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}

export function GuildOverview() {
  const { guildId } = useParams<{ guildId: string }>();
  const { data: guild, isLoading: guildLoading } = useGetGuild(guildId!, {
    query: { enabled: !!guildId },
  });
  const { data: analytics, isLoading: analyticsLoading } = useGetGuildAnalytics(guildId!, {
    query: { enabled: !!guildId },
  });
  const { data: leaderboard, isLoading: lbLoading } = useGetLeaderboard(guildId!, {
    query: { enabled: !!guildId },
  });

  const chartData = analytics?.memberGrowth?.map((d) => ({
    date: d.date?.slice(5),
    members: d.value,
  })) ?? [];

  const msgData = analytics?.messageActivity?.map((d) => ({
    date: d.date?.slice(5),
    messages: d.value,
  })) ?? [];

  return (
    <DashboardLayout guildId={guildId}>
      <div className="space-y-8">
        <div>
          {guildLoading ? (
            <Skeleton className="h-8 w-48 bg-border" />
          ) : (
            <h1 className="text-3xl font-bold">{guild?.name}</h1>
          )}
          <p className="text-muted-foreground mt-1">Server overview and analytics</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Members" value={guild?.memberCount} icon={Users} isLoading={guildLoading} />
          <StatCard label="Messages (30d)" value={analytics?.messageCount} icon={MessageSquare} isLoading={analyticsLoading} />
          <StatCard label="Commands (30d)" value={analytics?.commandsUsed} icon={TerminalSquare} isLoading={analyticsLoading} />
          <StatCard label="Tickets (30d)" value={analytics?.ticketsOpened} icon={Ticket} isLoading={analyticsLoading} />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="font-semibold mb-4 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              Member Growth
            </h2>
            {analyticsLoading ? (
              <Skeleton className="h-48 bg-border rounded" />
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="memberGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f5c542" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#f5c542" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="date" tick={{ fill: "#999", fontSize: 11 }} />
                  <YAxis tick={{ fill: "#999", fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ background: "#1a1a1a", border: "1px solid #333", borderRadius: 8 }}
                    labelStyle={{ color: "#fff" }}
                  />
                  <Area type="monotone" dataKey="members" stroke="#f5c542" fill="url(#memberGradient)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>

          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="font-semibold mb-4 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-primary" />
              Message Activity
            </h2>
            {analyticsLoading ? (
              <Skeleton className="h-48 bg-border rounded" />
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={msgData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="date" tick={{ fill: "#999", fontSize: 11 }} />
                  <YAxis tick={{ fill: "#999", fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ background: "#1a1a1a", border: "1px solid #333", borderRadius: 8 }}
                    labelStyle={{ color: "#fff" }}
                  />
                  <Bar dataKey="messages" fill="#f5c542" radius={[4, 4, 0, 0]} opacity={0.85} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Top Leaderboard */}
        <div className="bg-card border border-border rounded-xl p-6">
          <h2 className="font-semibold mb-4 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-primary" />
            Top Members
          </h2>
          {lbLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-12 bg-border rounded" />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {(leaderboard ?? []).slice(0, 5).map((entry, i) => (
                <div
                  key={entry.userId}
                  className="flex items-center gap-4 p-3 rounded-lg bg-background border border-border"
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                      i === 0
                        ? "bg-yellow-500/20 text-yellow-400"
                        : i === 1
                        ? "bg-zinc-400/20 text-zinc-300"
                        : i === 2
                        ? "bg-amber-700/20 text-amber-600"
                        : "bg-white/5 text-muted-foreground"
                    }`}
                  >
                    {i + 1}
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">{entry.username ?? entry.userId}</div>
                    <div className="text-xs text-muted-foreground">Level {entry.level}</div>
                  </div>
                  <div className="text-sm font-mono text-primary">
                    {entry.xp?.toLocaleString()} XP
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
