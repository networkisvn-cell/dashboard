import { useParams } from "wouter";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import {
  useGetEconomySettings,
} from "@workspace/api-client-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { Coins, Save } from "lucide-react";

export function EconomyPage() {
  const { guildId } = useParams<{ guildId: string }>();
  const { toast } = useToast();
  const { data, isLoading } = useGetEconomySettings(guildId!, {
    query: { enabled: !!guildId },
  });

  const [form, setForm] = useState({
    enabled: true,
    currencyName: "Coins",
    currencySymbol: "🪙",
    dailyAmount: 500,
    workMinAmount: 100,
    workMaxAmount: 500,
    startingBalance: 1000,
  });

  useEffect(() => {
    if (data) {
      setForm({
        enabled: data.enabled ?? true,
        currencyName: data.currencyName ?? "Coins",
        currencySymbol: data.currencySymbol ?? "🪙",
        dailyAmount: data.dailyAmount ?? 500,
        workMinAmount: data.workMinAmount ?? 100,
        workMaxAmount: data.workMaxAmount ?? 500,
        startingBalance: data.startingBalance ?? 1000,
      });
    }
  }, [data]);

  const handleSave = () => {
    toast({ title: "Saved", description: "Economy settings updated." });
  };

  return (
    <DashboardLayout guildId={guildId}>
      <div className="space-y-8 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Coins className="w-8 h-8 text-primary" />
            Economy System
          </h1>
          <p className="text-muted-foreground mt-1">Configure your server's virtual economy</p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 bg-border rounded-xl" />)}
          </div>
        ) : (
          <>
            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">Enable Economy</Label>
                  <p className="text-sm text-muted-foreground">Enable the virtual economy for your server</p>
                </div>
                <Switch
                  checked={form.enabled}
                  onCheckedChange={(v) => setForm((f) => ({ ...f, enabled: v }))}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Currency Name</Label>
                  <Input
                    value={form.currencyName}
                    onChange={(e) => setForm((f) => ({ ...f, currencyName: e.target.value }))}
                    className="bg-background border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Currency Symbol</Label>
                  <Input
                    value={form.currencySymbol}
                    onChange={(e) => setForm((f) => ({ ...f, currencySymbol: e.target.value }))}
                    className="bg-background border-border"
                    maxLength={4}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Starting Balance</Label>
                <Input
                  type="number"
                  min={0}
                  value={form.startingBalance}
                  onChange={(e) => setForm((f) => ({ ...f, startingBalance: parseInt(e.target.value) || 0 }))}
                  className="bg-background border-border max-w-xs"
                />
                <p className="text-xs text-muted-foreground">Amount given to new members</p>
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <h3 className="font-semibold">Daily & Work Rewards</h3>
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label>Daily Reward Amount</Label>
                  <Input
                    type="number"
                    min={1}
                    value={form.dailyAmount}
                    onChange={(e) => setForm((f) => ({ ...f, dailyAmount: parseInt(e.target.value) || 0 }))}
                    className="bg-background border-border max-w-xs"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Work Min Amount</Label>
                    <Input
                      type="number"
                      min={1}
                      value={form.workMinAmount}
                      onChange={(e) => setForm((f) => ({ ...f, workMinAmount: parseInt(e.target.value) || 0 }))}
                      className="bg-background border-border"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Work Max Amount</Label>
                    <Input
                      type="number"
                      min={1}
                      value={form.workMaxAmount}
                      onChange={(e) => setForm((f) => ({ ...f, workMaxAmount: parseInt(e.target.value) || 0 }))}
                      className="bg-background border-border"
                    />
                  </div>
                </div>
              </div>
            </div>

            <Button
              onClick={handleSave}
              className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Save className="w-4 h-4" />
              Save Changes
            </Button>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
