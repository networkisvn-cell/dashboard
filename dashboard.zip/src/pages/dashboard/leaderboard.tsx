import { useParams } from "wouter";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import { useGetLeaderboard } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy } from "lucide-react";

export function LeaderboardPage() {
  const { guildId } = useParams<{ guildId: string }>();
  const { data: leaderboard, isLoading } = useGetLeaderboard(guildId!, {
    query: { enabled: !!guildId },
  });

  const medals = ["🥇", "🥈", "🥉"];

  return (
    <DashboardLayout guildId={guildId}>
      <div className="space-y-8 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Trophy className="w-8 h-8 text-primary" />
            XP Leaderboard
          </h1>
          <p className="text-muted-foreground mt-1">Top members by experience points</p>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 10 }).map((_, i) => (
              <Skeleton key={i} className="h-16 bg-border rounded-xl" />
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {(leaderboard ?? []).map((entry, i) => (
              <div
                key={entry.userId}
                className={`flex items-center gap-4 p-4 rounded-xl border transition-colors ${
                  i < 3
                    ? "bg-primary/5 border-primary/20"
                    : "bg-card border-border"
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg ${
                    i === 0
                      ? "bg-yellow-500/20 text-yellow-400"
                      : i === 1
                      ? "bg-zinc-400/20 text-zinc-300"
                      : i === 2
                      ? "bg-amber-700/20 text-amber-600"
                      : "bg-white/5 text-muted-foreground text-sm"
                  }`}
                >
                  {i < 3 ? medals[i] : i + 1}
                </div>

                {entry.avatar ? (
                  <img
                    src={entry.avatar}
                    alt={entry.username ?? ""}
                    className="w-10 h-10 rounded-full border border-border"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-secondary border border-border flex items-center justify-center font-bold text-sm">
                    {(entry.username ?? "U")[0].toUpperCase()}
                  </div>
                )}

                <div className="flex-1 min-w-0">
                  <div className="font-semibold truncate">{entry.username ?? entry.userId}</div>
                  <div className="text-sm text-muted-foreground">Level {entry.level}</div>
                </div>

                <div className="text-right">
                  <div className="font-mono text-primary font-semibold">
                    {entry.xp?.toLocaleString()} XP
                  </div>
                  <div className="text-xs text-muted-foreground">Rank #{i + 1}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
