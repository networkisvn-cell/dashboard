import { useListGuilds } from "@workspace/api-client-react";
import { Link } from "wouter";
import { ShieldAlert, Users, Server, Crown, Search } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export function GuildSelector() {
  const { data: guilds, isLoading } = useListGuilds();
  const [search, setSearch] = useState("");

  const filteredGuilds = guilds?.filter(g => g.name.toLowerCase().includes(search.toLowerCase())) || [];

  return (
    <div className="min-h-screen bg-[#050505] text-foreground flex flex-col p-6 md:p-10">
      <div className="max-w-6xl mx-auto w-full">
        <header className="flex items-center justify-between mb-12">
          <Link href="/" className="flex items-center gap-2 text-primary font-bold text-xl tracking-wider uppercase">
            <ShieldAlert className="w-6 h-6" />
            NAKKHOTRO
          </Link>
          <div className="text-sm text-muted-foreground bg-white/5 px-4 py-2 rounded-full border border-white/5">
            Select a server to manage
          </div>
        </header>

        <div className="flex flex-col gap-6 mb-10">
          <h1 className="text-4xl font-bold tracking-tight">Your Servers</h1>
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search servers..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-white/5 border-white/10 h-12 text-lg focus-visible:ring-primary focus-visible:border-primary"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="p-6 rounded-2xl bg-white/5 border border-white/5 h-[160px] flex items-center gap-4">
                <Skeleton className="w-16 h-16 rounded-full bg-white/10" />
                <div className="flex flex-col gap-2 flex-1">
                  <Skeleton className="h-6 w-3/4 bg-white/10" />
                  <Skeleton className="h-4 w-1/2 bg-white/10" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredGuilds.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGuilds.map(guild => (
              <Link key={guild.id} href={`/dashboard/${guild.id}`}>
                <div className="p-6 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 hover:border-primary/50 transition-all cursor-pointer group flex items-center gap-5 relative overflow-hidden">
                  {guild.premiumTier && guild.premiumTier > 0 && (
                    <div className="absolute top-0 right-0 w-16 h-16 overflow-hidden">
                      <div className="absolute top-2 -right-6 bg-primary text-primary-foreground text-[10px] font-bold py-1 px-8 rotate-45 flex items-center gap-1 shadow-[0_0_10px_rgba(245,197,66,0.3)]">
                        <Crown className="w-3 h-3" />
                      </div>
                    </div>
                  )}
                  
                  {guild.icon ? (
                    <img src={guild.icon} alt={guild.name} className="w-16 h-16 rounded-full border border-white/10 group-hover:border-primary/50 transition-colors" />
                  ) : (
                    <div className="w-16 h-16 rounded-full bg-secondary border border-white/10 group-hover:border-primary/50 flex items-center justify-center font-bold text-xl text-muted-foreground group-hover:text-primary transition-colors">
                      {guild.name[0]}
                    </div>
                  )}
                  
                  <div className="flex flex-col overflow-hidden">
                    <h3 className="font-bold text-lg truncate group-hover:text-primary transition-colors">{guild.name}</h3>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                      <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {guild.memberCount.toLocaleString()}</span>
                      {guild.isOnline !== undefined && (
                        <span className="flex items-center gap-1">
                          <span className={`w-2 h-2 rounded-full ${guild.isOnline ? 'bg-green-500' : 'bg-destructive'}`} />
                          {guild.isOnline ? 'Online' : 'Offline'}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center bg-white/5 border border-white/5 rounded-2xl">
            <Server className="w-12 h-12 text-muted-foreground mb-4 opacity-50" />
            <h3 className="text-xl font-bold mb-2">No servers found</h3>
            <p className="text-muted-foreground max-w-md">
              We couldn't find any servers matching your search or you don't have manage permissions in any servers with NAKKHOTRO.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}