import { useParams } from "wouter";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import { useListAuditLogs } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollText } from "lucide-react";

const TYPE_COLORS: Record<string, string> = {
  BAN: "bg-red-500/20 text-red-400 border-red-500/30",
  UNBAN: "bg-green-500/20 text-green-400 border-green-500/30",
  KICK: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  TIMEOUT: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  UNTIMEOUT: "bg-green-500/20 text-green-400 border-green-500/30",
  WARN: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  UNWARN: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  MUTE: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  UNMUTE: "bg-green-500/20 text-green-400 border-green-500/30",
  SOFTBAN: "bg-red-500/20 text-red-400 border-red-500/30",
  PURGE: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  LOCK: "bg-red-500/20 text-red-400 border-red-500/30",
  UNLOCK: "bg-green-500/20 text-green-400 border-green-500/30",
  AUTOMOD: "bg-purple-500/20 text-purple-400 border-purple-500/30",
};

const formatTime = (iso: string) => {
  const d = new Date(iso);
  return d.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

export function LogsPage() {
  const { guildId } = useParams<{ guildId: string }>();
  const { data: logs, isLoading } = useListAuditLogs(guildId!, {
    query: { enabled: !!guildId },
  });

  return (
    <DashboardLayout guildId={guildId}>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <ScrollText className="w-8 h-8 text-primary" />
            Audit Logs
          </h1>
          <p className="text-muted-foreground mt-1">Recent moderation actions in your server</p>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 10 }).map((_, i) => (
              <Skeleton key={i} className="h-16 bg-border rounded-xl" />
            ))}
          </div>
        ) : (
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-background/50">
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Action</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Moderator</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Target</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Reason</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {(logs ?? []).map((log) => (
                    <tr key={log.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="p-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold border ${
                            TYPE_COLORS[log.type ?? ""] ?? "bg-white/5 text-muted-foreground border-border"
                          }`}
                        >
                          {log.type}
                        </span>
                      </td>
                      <td className="p-4">
                        <span className="text-sm font-medium">{log.moderatorName}</span>
                      </td>
                      <td className="p-4">
                        <span className="text-sm text-muted-foreground">{log.targetName}</span>
                      </td>
                      <td className="p-4 max-w-xs">
                        <span className="text-sm text-muted-foreground truncate block">
                          {log.reason ?? "No reason provided"}
                        </span>
                      </td>
                      <td className="p-4">
                        <span className="text-xs text-muted-foreground whitespace-nowrap">
                          {log.timestamp ? formatTime(log.timestamp) : "—"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {(logs ?? []).length === 0 && (
                <div className="text-center py-16 text-muted-foreground">
                  <ScrollText className="w-10 h-10 mx-auto mb-3 opacity-30" />
                  <p>No audit logs yet</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
