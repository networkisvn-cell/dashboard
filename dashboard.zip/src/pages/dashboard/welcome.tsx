import { useParams } from "wouter";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import {
  useGetWelcomeSettings,
  useUpdateWelcomeSettings,
} from "@workspace/api-client-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { MessageSquare, Save } from "lucide-react";

export function WelcomePage() {
  const { guildId } = useParams<{ guildId: string }>();
  const { toast } = useToast();
  const { data, isLoading } = useGetWelcomeSettings(guildId!, {
    query: { enabled: !!guildId },
  });
  const { mutate, isPending } = useUpdateWelcomeSettings();

  const [form, setForm] = useState({
    enabled: false,
    channelId: "",
    message: "Welcome {user} to **{server}**! You are member #{count}.",
    backgroundUrl: "",
    autoRoleId: "",
    dmEnabled: false,
    dmMessage: "Welcome to {server}!",
  });

  useEffect(() => {
    if (data) {
      setForm({
        enabled: data.enabled ?? false,
        channelId: data.channelId ?? "",
        message: data.message ?? "Welcome {user} to **{server}**! You are member #{count}.",
        backgroundUrl: data.backgroundUrl ?? "",
        autoRoleId: data.autoRoleId ?? "",
        dmEnabled: data.dmEnabled ?? false,
        dmMessage: data.dmMessage ?? "Welcome to {server}!",
      });
    }
  }, [data]);

  const handleSave = () => {
    mutate(
      { guildId: guildId!, data: form },
      {
        onSuccess: () =>
          toast({ title: "Saved", description: "Welcome settings updated." }),
        onError: () =>
          toast({ title: "Error", description: "Failed to save.", variant: "destructive" }),
      },
    );
  };

  return (
    <DashboardLayout guildId={guildId}>
      <div className="space-y-8 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <MessageSquare className="w-8 h-8 text-primary" />
            Welcome System
          </h1>
          <p className="text-muted-foreground mt-1">Configure welcome and farewell messages</p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 bg-border rounded-xl" />)}
          </div>
        ) : (
          <>
            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">Enable Welcome</Label>
                  <p className="text-sm text-muted-foreground">Send a welcome message when a member joins</p>
                </div>
                <Switch
                  checked={form.enabled}
                  onCheckedChange={(v) => setForm((f) => ({ ...f, enabled: v }))}
                />
              </div>

              <div className="space-y-2">
                <Label>Welcome Channel ID</Label>
                <Input
                  value={form.channelId}
                  onChange={(e) => setForm((f) => ({ ...f, channelId: e.target.value }))}
                  placeholder="Channel ID..."
                  className="bg-background border-border"
                  disabled={!form.enabled}
                />
              </div>

              <div className="space-y-2">
                <Label>Welcome Message</Label>
                <Textarea
                  value={form.message}
                  onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                  placeholder="Welcome message..."
                  className="bg-background border-border min-h-[100px]"
                  disabled={!form.enabled}
                />
                <p className="text-xs text-muted-foreground">
                  Variables: <code className="text-primary">{"{user}"}</code>{" "}
                  <code className="text-primary">{"{server}"}</code>{" "}
                  <code className="text-primary">{"{count}"}</code>
                </p>
              </div>

              <div className="space-y-2">
                <Label>Auto-Role ID</Label>
                <Input
                  value={form.autoRoleId}
                  onChange={(e) => setForm((f) => ({ ...f, autoRoleId: e.target.value }))}
                  placeholder="Role ID to assign on join..."
                  className="bg-background border-border"
                />
              </div>

              <div className="space-y-2">
                <Label>Background Image URL</Label>
                <Input
                  value={form.backgroundUrl}
                  onChange={(e) => setForm((f) => ({ ...f, backgroundUrl: e.target.value }))}
                  placeholder="https://..."
                  className="bg-background border-border"
                />
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">DM Welcome</Label>
                  <p className="text-sm text-muted-foreground">Also send a DM when members join</p>
                </div>
                <Switch
                  checked={form.dmEnabled}
                  onCheckedChange={(v) => setForm((f) => ({ ...f, dmEnabled: v }))}
                />
              </div>

              {form.dmEnabled && (
                <div className="space-y-2">
                  <Label>DM Message</Label>
                  <Textarea
                    value={form.dmMessage}
                    onChange={(e) => setForm((f) => ({ ...f, dmMessage: e.target.value }))}
                    className="bg-background border-border"
                  />
                </div>
              )}
            </div>

            <Button
              onClick={handleSave}
              disabled={isPending}
              className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Save className="w-4 h-4" />
              {isPending ? "Saving..." : "Save Changes"}
            </Button>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
